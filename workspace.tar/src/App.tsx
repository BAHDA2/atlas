import { useState, useEffect } from "react";

// Product data
const products = [
  {
    id: 1,
    name: "ATLAS Oversized Hoodie",
    price: "450 DH",
    image: "https://image.qwenlm.ai/generated-images/e833931d-8110-45d9-9202-97188edb59d7/_result.png",
    category: "Hoodies",
  },
  {
    id: 2,
    name: "Medina Sweatshirt",
    price: "380 DH",
    image: "https://image.qwenlm.ai/generated-images/1ae1f006-720f-4559-9806-v428a0b03f45/_result.png",
    category: "Sweatshirts",
  },
  {
    id: 3,
    name: "Riad Graphic Tee",
    price: "250 DH",
    image: "https://image.qwenlm.ai/generated-images/798f8a83-3c86-4138-af97-1fabf29bd2d8/_result.png",
    category: "T-Shirts",
  },
  {
    id: 4,
    name: "Sahara Crewneck",
    price: "350 DH",
    image: "https://image.qwenlm.ai/generated-images/911dea2c-0444-436d-a4ee-351aea342b1e/_result.png",
    category: "Sweatshirts",
  },
];

const customServices = [
  {
    icon: "🎨",
    title: "Design Personnalisé",
    description: "Envoyez votre design ou travaillez avec nos créateurs pour un rendu unique.",
  },
  {
    icon: "🖨️",
    title: "Impression Premium",
    description: "Techniques DTG, sérigraphie et broderie pour un résultat professionnel.",
  },
  {
    icon: "📦",
    title: "Commande en Gros",
    description: "Tarifs spéciaux pour les équipes, événements et entreprises.",
  },
  {
    icon: "🚚",
    title: "Livraison Gratuite",
    description: "Partout au Maroc, sans minimum de commande. Rapide et sécurisé.",
  },
];

function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-black/95 backdrop-blur-md shadow-lg" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <a href="#" className="text-2xl sm:text-3xl font-black tracking-tighter text-white">
            ATLAS<span className="text-amber-500">.</span>
          </a>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#accueil" className="text-white/80 hover:text-amber-500 transition-colors text-sm uppercase tracking-wider font-medium">
              Accueil
            </a>
            <a href="#produits" className="text-white/80 hover:text-amber-500 transition-colors text-sm uppercase tracking-wider font-medium">
              Produits
            </a>
            <a href="#custom" className="text-white/80 hover:text-amber-500 transition-colors text-sm uppercase tracking-wider font-medium">
              Custom
            </a>
            <a href="#contact" className="text-white/80 hover:text-amber-500 transition-colors text-sm uppercase tracking-wider font-medium">
              Contact
            </a>
            <a
              href="#contact"
              className="bg-amber-500 hover:bg-amber-600 text-black font-bold px-5 py-2 rounded-none text-sm uppercase tracking-wider transition-colors"
            >
              Commander
            </a>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden text-white p-2"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {menuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="md:hidden bg-black/95 backdrop-blur-md pb-6">
            <div className="flex flex-col space-y-4">
              <a href="#accueil" onClick={() => setMenuOpen(false)} className="text-white/80 hover:text-amber-500 transition-colors text-sm uppercase tracking-wider font-medium">
                Accueil
              </a>
              <a href="#produits" onClick={() => setMenuOpen(false)} className="text-white/80 hover:text-amber-500 transition-colors text-sm uppercase tracking-wider font-medium">
                Produits
              </a>
              <a href="#custom" onClick={() => setMenuOpen(false)} className="text-white/80 hover:text-amber-500 transition-colors text-sm uppercase tracking-wider font-medium">
                Custom
              </a>
              <a href="#contact" onClick={() => setMenuOpen(false)} className="text-white/80 hover:text-amber-500 transition-colors text-sm uppercase tracking-wider font-medium">
                Contact
              </a>
              <a
                href="#contact"
                onClick={() => setMenuOpen(false)}
                className="bg-amber-500 hover:bg-amber-600 text-black font-bold px-5 py-2 text-sm uppercase tracking-wider transition-colors text-center"
              >
                Commander
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

function HeroSection() {
  return (
    <section id="accueil" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="https://image.qwenlm.ai/generated-images/0b41af16-682f-4239-b3a7-48a600e02aba/_result.png"
          alt="ATLAS Streetwear"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        <div className="mb-6 inline-block">
          <span className="bg-amber-500/20 border border-amber-500/50 text-amber-400 text-xs sm:text-sm uppercase tracking-widest px-4 py-2 font-medium">
            🇲🇦 Nouvelle Collection 2026
          </span>
        </div>
        <h1 className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-black text-white tracking-tighter leading-none mb-6">
          ATLAS<span className="text-amber-500">.</span>
        </h1>
        <p className="text-lg sm:text-xl md:text-2xl text-white/70 font-light max-w-2xl mx-auto mb-4">
          Streetwear Marocain — Vêtements Custom
        </p>
        <p className="text-base sm:text-lg text-white/50 max-w-xl mx-auto mb-10">
          Hoodies, sweatshirts, t-shirts et plus. Personnalisés avec ton style.
          Livraison gratuite partout au Maroc.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="#produits"
            className="bg-amber-500 hover:bg-amber-400 text-black font-bold px-8 py-4 text-sm uppercase tracking-wider transition-all hover:scale-105"
          >
            Voir la Collection
          </a>
          <a
            href="#custom"
            className="border-2 border-white/30 hover:border-amber-500 text-white hover:text-amber-500 font-bold px-8 py-4 text-sm uppercase tracking-wider transition-all hover:scale-105"
          >
            Créer Ton Design
          </a>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <svg className="w-6 h-6 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  );
}

function DeliveryBanner() {
  return (
    <div className="bg-amber-500 py-4 sm:py-5 overflow-hidden">
      <div className="flex items-center justify-center gap-4 sm:gap-8 animate-pulse">
        <span className="text-black font-bold text-sm sm:text-base uppercase tracking-wider">
          🚚 Livraison Gratuite Partout au Maroc
        </span>
        <span className="hidden sm:inline text-black/50">|</span>
        <span className="hidden sm:inline text-black font-bold text-sm uppercase tracking-wider">
          📦 Sans Minimum de Commande
        </span>
        <span className="hidden md:inline text-black/50">|</span>
        <span className="hidden md:inline text-black font-bold text-sm uppercase tracking-wider">
          ⚡ Expédition 24-48h
        </span>
      </div>
    </div>
  );
}

function ProductsSection() {
  return (
    <section id="produits" className="py-20 sm:py-28 bg-neutral-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-amber-500 text-sm uppercase tracking-widest font-medium">Collection</span>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-black text-white tracking-tighter mt-3">
            Nos Produits
          </h2>
          <p className="text-white/50 mt-4 max-w-lg mx-auto">
            Des pièces premium conçues pour le streetwear marocain. Qualité supérieure, style unique.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {products.map((product) => (
            <div
              key={product.id}
              className="group bg-neutral-900 border border-neutral-800 hover:border-amber-500/50 transition-all duration-300 overflow-hidden"
            >
              <div className="aspect-square overflow-hidden bg-neutral-800">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="p-5">
                <span className="text-amber-500/70 text-xs uppercase tracking-wider font-medium">
                  {product.category}
                </span>
                <h3 className="text-white font-bold text-lg mt-1 group-hover:text-amber-500 transition-colors">
                  {product.name}
                </h3>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-white font-bold text-xl">{product.price}</span>
                  <button className="bg-white/10 hover:bg-amber-500 hover:text-black text-white px-4 py-2 text-xs uppercase tracking-wider font-bold transition-all">
                    Commander
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <a
            href="#contact"
            className="inline-block border-2 border-amber-500 text-amber-500 hover:bg-amber-500 hover:text-black font-bold px-8 py-4 text-sm uppercase tracking-wider transition-all"
          >
            Voir Tous les Produits
          </a>
        </div>
      </div>
    </section>
  );
}

function CustomSection() {
  return (
    <section id="custom" className="py-20 sm:py-28 bg-black relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-96 h-96 bg-amber-500 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-amber-500 rounded-full blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-amber-500 text-sm uppercase tracking-widest font-medium">Service Custom</span>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-black text-white tracking-tighter mt-3">
            Crée Ton Style
          </h2>
          <p className="text-white/50 mt-4 max-w-2xl mx-auto">
            Personnalise tes vêtements avec tes propres designs. Impression haute qualité sur tous nos produits.
            Du simple logo au design complet — on réalise ta vision.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {customServices.map((service, index) => (
            <div
              key={index}
              className="bg-neutral-900/80 border border-neutral-800 hover:border-amber-500/50 p-8 text-center transition-all duration-300 hover:-translate-y-2"
            >
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="text-white font-bold text-lg mb-3">{service.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>

        {/* Process steps */}
        <div className="mt-20">
          <h3 className="text-2xl sm:text-3xl font-black text-white text-center mb-12 tracking-tight">
            Comment ça marche ?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { step: "01", title: "Choisis ton produit", desc: "Hoodie, sweatshirt, t-shirt..." },
              { step: "02", title: "Envoie ton design", desc: "Ou demande notre aide créative" },
              { step: "03", title: "On imprime", desc: "Qualité premium garantie" },
              { step: "04", title: "Livraison gratuite", desc: "Partout au Maroc en 24-48h" },
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="text-5xl sm:text-6xl font-black text-amber-500/20 mb-3">{item.step}</div>
                <h4 className="text-white font-bold text-lg mb-2">{item.title}</h4>
                <p className="text-white/50 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function AboutSection() {
  return (
    <section className="py-20 sm:py-28 bg-neutral-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <div>
            <span className="text-amber-500 text-sm uppercase tracking-widest font-medium">Notre Histoire</span>
            <h2 className="text-4xl sm:text-5xl font-black text-white tracking-tighter mt-3 mb-6">
              Né dans les Rues du Maroc
            </h2>
            <div className="space-y-4 text-white/60 leading-relaxed">
              <p>
                ATLAS est né d'une passion pour la culture streetwear et l'identité marocaine. 
                Nous croyons que chaque personne mérite des vêtements qui reflètent sa personnalité unique.
              </p>
              <p>
                Basé au Maroc, nous offrons des vêtements de qualité premium personnalisables. 
                Des hoodies aux t-shirts, chaque pièce est fabriquée avec soin et imprimée 
                avec les meilleures techniques disponibles.
              </p>
              <p>
                Notre mission : rendre le streetwear accessible à tous les Marocains, 
                avec un service de personnalisation unique et une livraison gratuite 
                dans tout le royaume.
              </p>
            </div>
            <div className="flex flex-wrap gap-8 mt-8">
              <div>
                <div className="text-3xl font-black text-amber-500">100%</div>
                <div className="text-white/50 text-sm uppercase tracking-wider mt-1">Coton Premium</div>
              </div>
              <div>
                <div className="text-3xl font-black text-amber-500">500+</div>
                <div className="text-white/50 text-sm uppercase tracking-wider mt-1">Clients Satisfaits</div>
              </div>
              <div>
                <div className="text-3xl font-black text-amber-500">24h</div>
                <div className="text-white/50 text-sm uppercase tracking-wider mt-1">Expédition</div>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-[4/5] bg-neutral-900 border border-neutral-800 overflow-hidden">
              <img
                src="https://image.qwenlm.ai/generated-images/0b41af16-682f-4239-b3a7-48a600e02aba/_result.png"
                alt="ATLAS Brand"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-amber-500 flex items-center justify-center">
              <div className="text-center">
                <div className="text-black font-black text-2xl">MADE IN</div>
                <div className="text-black font-black text-xl">MOROCCO</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function TestimonialsSection() {
  const testimonials = [
    {
      name: "Yassine K.",
      city: "Casablanca",
      text: "Qualité incroyable ! Mon hoodie personnalisé est parfait. La livraison était super rapide.",
      rating: 5,
    },
    {
      name: "Sara M.",
      city: "Marrakech",
      text: "J'ai commandé pour toute mon équipe. Le design custom est exactement ce qu'on voulait. Merci ATLAS !",
      rating: 5,
    },
    {
      name: "Omar B.",
      city: "Rabat",
      text: "Le meilleur streetwear au Maroc. Prix raisonnable et qualité au top. Je recommande à 100%.",
      rating: 5,
    },
  ];

  return (
    <section className="py-20 sm:py-28 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-amber-500 text-sm uppercase tracking-widest font-medium">Témoignages</span>
          <h2 className="text-4xl sm:text-5xl font-black text-white tracking-tighter mt-3">
            Ce Que Disent Nos Clients
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-neutral-900 border border-neutral-800 p-8 hover:border-amber-500/30 transition-all"
            >
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <span key={i} className="text-amber-500">★</span>
                ))}
              </div>
              <p className="text-white/70 leading-relaxed mb-6 italic">"{testimonial.text}"</p>
              <div>
                <div className="text-white font-bold">{testimonial.name}</div>
                <div className="text-white/40 text-sm">{testimonial.city}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    city: "",
    product: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    // In production, this would send to a backend
  };

  return (
    <section id="contact" className="py-20 sm:py-28 bg-neutral-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          <div>
            <span className="text-amber-500 text-sm uppercase tracking-widest font-medium">Contact</span>
            <h2 className="text-4xl sm:text-5xl font-black text-white tracking-tighter mt-3 mb-6">
              Passe Ta Commande
            </h2>
            <p className="text-white/50 mb-8 leading-relaxed">
              Prêt à créer ton style unique ? Envoie-nous un message et on te répond dans les plus brefs délais. 
              Livraison gratuite partout au Maroc !
            </p>

            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
                  <span className="text-xl">📱</span>
                </div>
                <div>
                  <div className="text-white font-bold">WhatsApp / Téléphone</div>
                  <div className="text-white/50">+212 6XX-XXXXXX</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
                  <span className="text-xl">📧</span>
                </div>
                <div>
                  <div className="text-white font-bold">Email</div>
                  <div className="text-white/50">contact@atlas-streetwear.ma</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
                  <span className="text-xl">📍</span>
                </div>
                <div>
                  <div className="text-white font-bold">Localisation</div>
                  <div className="text-white/50">Casablanca, Maroc</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
                  <span className="text-xl">📸</span>
                </div>
                <div>
                  <div className="text-white font-bold">Instagram</div>
                  <div className="text-white/50">@atlas.streetwear.ma</div>
                </div>
              </div>
            </div>
          </div>

          <div>
            {submitted ? (
              <div className="bg-neutral-900 border border-amber-500/30 p-12 text-center h-full flex flex-col items-center justify-center">
                <div className="text-5xl mb-4">✅</div>
                <h3 className="text-2xl font-black text-white mb-3">Merci !</h3>
                <p className="text-white/60">
                  Ta demande a été envoyée. On te contacte très bientôt sur WhatsApp !
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-6 text-amber-500 hover:text-amber-400 font-medium text-sm uppercase tracking-wider"
                >
                  Envoyer une autre demande
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="bg-neutral-900 border border-neutral-800 p-8">
                <div className="space-y-5">
                  <div>
                    <label className="text-white/70 text-sm uppercase tracking-wider font-medium block mb-2">
                      Nom complet
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-neutral-800 border border-neutral-700 text-white px-4 py-3 focus:border-amber-500 focus:outline-none transition-colors"
                      placeholder="Ton nom"
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="text-white/70 text-sm uppercase tracking-wider font-medium block mb-2">
                        Téléphone
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full bg-neutral-800 border border-neutral-700 text-white px-4 py-3 focus:border-amber-500 focus:outline-none transition-colors"
                        placeholder="+212 6XX-XXXXXX"
                      />
                    </div>
                    <div>
                      <label className="text-white/70 text-sm uppercase tracking-wider font-medium block mb-2">
                        Ville
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        className="w-full bg-neutral-800 border border-neutral-700 text-white px-4 py-3 focus:border-amber-500 focus:outline-none transition-colors"
                        placeholder="Ta ville"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-white/70 text-sm uppercase tracking-wider font-medium block mb-2">
                      Produit souhaité
                    </label>
                    <select
                      value={formData.product}
                      onChange={(e) => setFormData({ ...formData, product: e.target.value })}
                      className="w-full bg-neutral-800 border border-neutral-700 text-white px-4 py-3 focus:border-amber-500 focus:outline-none transition-colors"
                    >
                      <option value="">Sélectionner un produit</option>
                      <option value="hoodie">Hoodie Personnalisé</option>
                      <option value="sweatshirt">Sweatshirt Personnalisé</option>
                      <option value="tshirt">T-Shirt Personnalisé</option>
                      <option value="crewneck">Crewneck Personnalisé</option>
                      <option value="other">Autre</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-white/70 text-sm uppercase tracking-wider font-medium block mb-2">
                      Message / Détails
                    </label>
                    <textarea
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full bg-neutral-800 border border-neutral-700 text-white px-4 py-3 focus:border-amber-500 focus:outline-none transition-colors resize-none"
                      placeholder="Décris ton projet, quantité, design souhaité..."
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-amber-500 hover:bg-amber-400 text-black font-bold py-4 text-sm uppercase tracking-wider transition-all hover:scale-[1.02]"
                  >
                    Envoyer Ma Demande 🚀
                  </button>
                  <p className="text-white/30 text-xs text-center">
                    🚚 Livraison gratuite partout au Maroc • Réponse sous 24h
                  </p>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-black border-t border-neutral-800 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div className="md:col-span-2">
            <h3 className="text-3xl font-black text-white tracking-tighter mb-4">
              ATLAS<span className="text-amber-500">.</span>
            </h3>
            <p className="text-white/50 max-w-sm leading-relaxed">
              Streetwear marocain premium. Vêtements personnalisés avec livraison gratuite 
              partout au royaume.
            </p>
            <div className="flex gap-4 mt-6">
              <a href="#" className="w-10 h-10 bg-neutral-900 border border-neutral-800 hover:border-amber-500 flex items-center justify-center text-white/60 hover:text-amber-500 transition-all">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
              </a>
              <a href="#" className="w-10 h-10 bg-neutral-900 border border-neutral-800 hover:border-amber-500 flex items-center justify-center text-white/60 hover:text-amber-500 transition-all">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
              </a>
              <a href="#" className="w-10 h-10 bg-neutral-900 border border-neutral-800 hover:border-amber-500 flex items-center justify-center text-white/60 hover:text-amber-500 transition-all">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/></svg>
              </a>
            </div>
          </div>
          <div>
            <h4 className="text-white font-bold uppercase tracking-wider text-sm mb-4">Navigation</h4>
            <ul className="space-y-3">
              <li><a href="#accueil" className="text-white/50 hover:text-amber-500 transition-colors text-sm">Accueil</a></li>
              <li><a href="#produits" className="text-white/50 hover:text-amber-500 transition-colors text-sm">Produits</a></li>
              <li><a href="#custom" className="text-white/50 hover:text-amber-500 transition-colors text-sm">Custom</a></li>
              <li><a href="#contact" className="text-white/50 hover:text-amber-500 transition-colors text-sm">Contact</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold uppercase tracking-wider text-sm mb-4">Produits</h4>
            <ul className="space-y-3">
              <li><a href="#produits" className="text-white/50 hover:text-amber-500 transition-colors text-sm">Hoodies</a></li>
              <li><a href="#produits" className="text-white/50 hover:text-amber-500 transition-colors text-sm">Sweatshirts</a></li>
              <li><a href="#produits" className="text-white/50 hover:text-amber-500 transition-colors text-sm">T-Shirts</a></li>
              <li><a href="#produits" className="text-white/50 hover:text-amber-500 transition-colors text-sm">Crewnecks</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-neutral-800 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/30 text-sm">
            © 2026 ATLAS Streetwear. Tous droits réservés.
          </p>
          <p className="text-white/30 text-sm">
            🇲🇦 Fait avec ❤️ au Maroc
          </p>
        </div>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <div className="bg-black min-h-screen font-sans">
      <Navbar />
      <HeroSection />
      <DeliveryBanner />
      <ProductsSection />
      <CustomSection />
      <AboutSection />
      <TestimonialsSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
